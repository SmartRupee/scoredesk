# ScoreDesk Regression Suite

Runs the **actual parsing engine extracted live from `index.html`** against
every real (or realistically reconstructed) sample report collected so far,
and checks the results against `expected.json`. This is what should be run
before shipping any change to the parser, so a fix for one report format
can't silently break another without being caught immediately.

It does not hand-copy the parser into the suite — it pulls the real
`<script>` block straight out of whichever `index.html` you point it at, so
it's always testing the exact code that would ship, not a stale copy.

## Setup (one-time)

```
npm install
```

This installs `jsdom`, which is only needed to test the HTML-upload fixture
(`hirenshah_saved_html_page.html`) the same way a real browser's DOM would.
If you skip this step, every `.txt` (PDF-text) fixture still runs — the one
`.html` fixture will just print `SKIP` instead of `PASS`/`FAIL`.

## Running it

```
node run_suite.js path/to/index.html
```

Exits with code `0` if everything passes, `1` if anything fails — so it can
be wired into a CI step or a pre-deploy check later if wanted.

## Fixtures

| File | Format tested |
|---|---|
| `nilesh_tiwari_formatF.txt` | myscore.cibil.com full desktop export (headers and detail fields printed as two separate passes) |
| `mausham_formatA_cir.txt` | Consumer CIR (bureau-direct) layout |
| `hirenshah_formatB_mobile.txt` | myscore.cibil.com mobile view, `--` placeholders |
| `ambit_kisetsu_formatB_colon.txt` | "Member Name :LENDER" colon variant, table header + data row |
| `shaista_formatB_suppressed_header.txt` | Accounts table where the header row only prints once for the whole table |
| `waqas_chrome_formatB.txt` | Real 24-account report, Chrome print export (clean, no footer) |
| `waqas_safari_formatB_footer_stripped.txt` | Same report, Safari print export — tests the print-footer stripper |
| `rakhee_summaryonly.txt` | Summary-only report with no itemized accounts |
| `hirenshah_saved_html_page.html` | The HTML-upload path (DOM parsing via `htmlToText`, not PDF text) |

## Adding a new fixture

1. Drop the sample's extracted text (or saved `.html` page) into `fixtures/`.
2. Add an entry to `expected.json` with the values you expect: `consumerName`,
   `score`, `minAccounts`, `enquiries`, `maxArtifacts` (how many self-check
   warnings are acceptable — usually `0`), and `isHtml: true` if it's an
   `.html` fixture.
3. Run the suite. If it's a new bug you're fixing, this is a good moment to
   confirm it fails first, then fix `index.html`, then confirm it passes.

Every real sample report anyone sends should end up here eventually — that's
what turns "a user hit a new bug" into a permanent, one-time cost instead of
a recurring one.
