# ScoreDesk regression suite (encrypted)

Runs the real parsing code from a given `index.html` against a set of sample
reports and checks the results. The samples contain personal data, so they
live **encrypted** in `vault/` — see `VAULT-GUIDE.md`.

```
npm install                                   # once (jsdom, for the HTML fixture)
node run_suite.js path/to/index.html --key scoredesk-vault.key
node unit_tests.js path/to/index.html
```

Run this before every release. Every new real report that fails in the wild
should be added to the vault as a permanent test.
