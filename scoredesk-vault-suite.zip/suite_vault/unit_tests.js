// Unit tests for pure helpers that live outside the parsing-engine span.
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const html = fs.readFileSync(process.argv[2], 'utf8');
const main = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]).sort((a,b)=>b.length-a.length)[0];
const pick = n => { const m = main.match(new RegExp('function ' + n + '\\([^)]*\\)\\{[\\s\\S]*?\\n\\}\\n')); assert(m, n + ' not found'); return m[0]; };
const sb = {}; vm.createContext(sb);
vm.runInContext(pick('planOcrBands') + pick('mergeBandTexts') + 'this.plan=planOcrBands;this.merge=mergeBandTexts;', sb);

// 1. short image => single band
assert.strictEqual(JSON.stringify(sb.plan(1080, 1500)), JSON.stringify([{ y: 0, h: 1500 }]));
// 2. tall phone screenshot: bands cover every pixel, each overlaps the next
const W = 1080, H = 9000, bands = sb.plan(W, H);
assert(bands.length > 3);
assert.strictEqual(bands[0].y, 0);
const last = bands[bands.length - 1];
assert.strictEqual(last.y + last.h, H, 'last band must reach the bottom');
for (let i = 1; i < bands.length; i++) assert(bands[i].y < bands[i-1].y + bands[i-1].h, 'bands must overlap');
bands.forEach(b => assert(b.h <= 2200 * 1.25 && b.h > 0));
assert(bands[bands.length-1].h >= 800 * 0.25, 'no tiny trailing sliver');
// 3. very narrow tall image still terminates and covers everything
const nb = sb.plan(300, 12000); assert.strictEqual(nb[nb.length-1].y + nb[nb.length-1].h, 12000);

// 4. merge drops lines duplicated by the overlap, keeps legit repeats elsewhere
const merged = sb.merge([
  'Account Type\nCredit Card\nOwnership\nIndividual',
  'Ownership\nIndividual\nDate Opened\n12/03/2021\nOwnership\nJoint'
]);
assert.strictEqual(merged, 'Account Type\nCredit Card\nOwnership\nIndividual\nDate Opened\n12/03/2021\nOwnership\nJoint');
// 5. no overlap => nothing dropped
assert.strictEqual(sb.merge(['a\nb', 'c\nd']), 'a\nb\nc\nd');
// 6. blank leading lines in a later band are skipped
assert.strictEqual(sb.merge(['x\ny', '\n\ny\nz']), 'x\ny\nz');
console.log('unit tests passed: planOcrBands (3), mergeBandTexts (3)');
