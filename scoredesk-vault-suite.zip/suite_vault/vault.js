#!/usr/bin/env node
/**
 * ScoreDesk Vault — encrypts the regression suite's data (real report text,
 * expected results, even the file NAMES) so it is unreadable without a key.
 *
 * Cipher: AES-256-GCM (standard, authenticated). The "ScoreDesk Vault"
 * container (.sdv) is just a labelled wrapper — all the secrecy comes from
 * the 256-bit key, never from the format being obscure. Needs only Node's
 * built-in crypto: no installs, runs in Termux on a phone.
 *
 *   node vault.js keygen  my.key
 *   node vault.js seal    <plain_dir> <vault_dir> --key my.key
 *   node vault.js list    <vault_dir>             --key my.key
 *   node vault.js cat     <vault_dir> <name>      --key my.key
 *   node vault.js add     <file> <vault_dir>      --key my.key
 *   node vault.js open    <vault_dir> <out_dir>   --key my.key   (writes PLAINTEXT)
 *   node vault.js rekey   <vault_dir> <new_dir>   --key old.key --new new.key
 *   node vault.js verify  <vault_dir>             --key my.key
 *
 * File layout:  "SDV1" | keyId(4) | nonce(12) | ciphertext | GCM tag(16)
 * AAD binds each blob to its own logical name, so encrypted files cannot be
 * swapped/renamed without detection. Physical filenames are HMAC-derived,
 * so the folder reveals neither names nor how files relate.
 */
const crypto = require('crypto'), fs = require('fs'), path = require('path');

const MAGIC = Buffer.from('SDV1');
const MANIFEST = '__manifest__';

function readKey(p){
  if (!p) throw new Error('No key file given (use --key <file>).');
  const t = fs.readFileSync(p, 'utf8');
  const m = t.match(/^key:\s*([A-Za-z0-9+/=]+)\s*$/m);
  if (!m) throw new Error(`"${p}" is not a ScoreDesk vault key file.`);
  const key = Buffer.from(m[1], 'base64');
  if (key.length !== 32) throw new Error('Key file is damaged (wrong length).');
  return key;
}
const keyId = key => crypto.createHash('sha256').update(key).digest().subarray(0, 4);
const physName = (key, logical) =>
  crypto.createHmac('sha256', key).update('name:' + logical).digest('hex').slice(0, 24) + '.sdv';

function seal(key, logical, buf){
  const nonce = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, nonce);
  c.setAAD(Buffer.concat([MAGIC, keyId(key), Buffer.from(logical)]));
  const ct = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([MAGIC, keyId(key), nonce, ct, c.getAuthTag()]);
}

function unseal(key, logical, blob){
  if (blob.length < 4 + 4 + 12 + 16 || !blob.subarray(0, 4).equals(MAGIC))
    throw new Error(`"${logical}" is not a ScoreDesk vault file.`);
  const fid = blob.subarray(4, 8);
  if (!fid.equals(keyId(key)))
    throw new Error(`Wrong key: this vault was sealed with key ${fid.toString('hex')}, ` +
                    `the key you gave is ${keyId(key).toString('hex')}.`);
  const d = crypto.createDecipheriv('aes-256-gcm', key, blob.subarray(8, 20));
  d.setAAD(Buffer.concat([MAGIC, fid, Buffer.from(logical)]));
  d.setAuthTag(blob.subarray(blob.length - 16));
  try { return Buffer.concat([d.update(blob.subarray(20, blob.length - 16)), d.final()]); }
  catch (e){ throw new Error(`TAMPERED or corrupted: "${logical}" failed authentication.`); }
}

function writeVault(key, vaultDir, files /* Map logical->Buffer */){
  fs.mkdirSync(vaultDir, { recursive: true });
  for (const f of fs.readdirSync(vaultDir)) if (f.endsWith('.sdv')) fs.unlinkSync(path.join(vaultDir, f));
  for (const [name, buf] of files) fs.writeFileSync(path.join(vaultDir, physName(key, name)), seal(key, name, buf));
  fs.writeFileSync(path.join(vaultDir, 'manifest.sdv'),
    seal(key, MANIFEST, Buffer.from(JSON.stringify({ v: 1, files: [...files.keys()].sort() }))));
}

/** Decrypts a whole vault into memory (never touches disk). */
function loadVault(vaultDir, keyPath){
  const key = readKey(keyPath);
  const mp = path.join(vaultDir, 'manifest.sdv');
  if (!fs.existsSync(mp)) throw new Error(`No vault found in "${vaultDir}" (manifest.sdv missing).`);
  const manifest = JSON.parse(unseal(key, MANIFEST, fs.readFileSync(mp)).toString());
  const files = new Map();
  for (const name of manifest.files){
    const p = path.join(vaultDir, physName(key, name));
    if (!fs.existsSync(p)) throw new Error(`Vault is missing an encrypted file listed in its manifest.`);
    files.set(name, unseal(key, name, fs.readFileSync(p)));
  }
  return files;
}

module.exports = { loadVault, readKey };

// ------------------------------------------------------------------ CLI ---
if (require.main === module){
  const args = process.argv.slice(2);
  const flag = n => { const i = args.indexOf('--' + n); return i >= 0 ? args.splice(i, 2)[1] : null; };
  const keyPath = flag('key'), newKeyPath = flag('new');
  const [cmd, a, b] = args;
  try {
    if (cmd === 'keygen'){
      if (!a) throw new Error('Usage: vault.js keygen <keyfile>');
      if (fs.existsSync(a)) throw new Error(`"${a}" already exists — refusing to overwrite a key.`);
      const key = crypto.randomBytes(32);
      fs.writeFileSync(a,
        `SCOREDESK-VAULT-KEY v1\nkeyId: ${keyId(key).toString('hex')}\nkey: ${key.toString('base64')}\n` +
        `# SECRET. Anyone holding this file can read the vault. Never put it in GitHub,\n` +
        `# never store it next to the vault. Lose it and the data is gone for good.\n`, { mode: 0o600 });
      console.log(`Key written to ${a}  (id ${keyId(key).toString('hex')})`);
    } else if (cmd === 'seal'){
      const key = readKey(keyPath), files = new Map();
      for (const f of fs.readdirSync(a)) if (fs.statSync(path.join(a, f)).isFile()) files.set(f, fs.readFileSync(path.join(a, f)));
      writeVault(key, b, files);
      console.log(`Sealed ${files.size} files into ${b}/`);
    } else if (cmd === 'list' || cmd === 'verify'){
      const files = loadVault(a, keyPath);
      if (cmd === 'verify') console.log(`OK — all ${files.size} files decrypt and authenticate.`);
      else for (const [n, buf] of files) console.log(String(buf.length).padStart(9), n);
    } else if (cmd === 'cat'){
      const files = loadVault(a, keyPath);
      if (!files.has(b)) throw new Error(`No file "${b}" in the vault (try: list).`);
      process.stdout.write(files.get(b));
    } else if (cmd === 'add'){
      const key = readKey(keyPath);
      const files = fs.existsSync(path.join(b, 'manifest.sdv')) ? loadVault(b, keyPath) : new Map();
      files.set(path.basename(a), fs.readFileSync(a));
      writeVault(key, b, files);
      console.log(`Added ${path.basename(a)} (${files.size} files now in vault). Delete the plaintext original.`);
    } else if (cmd === 'open'){
      const files = loadVault(a, keyPath);
      fs.mkdirSync(b, { recursive: true });
      for (const [n, buf] of files) fs.writeFileSync(path.join(b, n), buf);
      console.log(`Wrote ${files.size} PLAINTEXT files to ${b}/ — delete them when done.`);
    } else if (cmd === 'rekey'){
      const files = loadVault(a, keyPath);
      writeVault(readKey(newKeyPath), b, files);
      console.log(`Re-encrypted ${files.size} files into ${b}/ under the new key. Destroy the old key + old vault.`);
    } else {
      console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0].replace(/^#!.*\n\/\*\*\n?/, '').replace(/^ \* ?/gm, ''));
    }
  } catch (e){ console.error('ERROR: ' + e.message); process.exit(1); }
}
