#!/usr/bin/env node
/**
 * ScoreDesk regression suite.
 *
 * Runs the ACTUAL parsing code from a given index.html against every real
 * (or realistically reconstructed) sample report in fixtures/, and checks
 * the result against expected.json. This is what should be run before
 * shipping any change to the parser, so a fix for one format can't silently
 * break another without being caught immediately.
 *
 * Usage:
 *   node run_suite.js path/to/index.html
 *
 * Exits non-zero if any fixture fails, so it can be used as a CI gate too.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Usage: node run_suite.js path/to/index.html --key my.key [--vault ./vault]
// The suite's data lives ONLY in an encrypted vault; it is decrypted in
// memory for the run and never written to disk. (--plain <dir> exists for
// a developer testing with their own non-sensitive fixtures.)
const argv = process.argv.slice(2);
const opt = n => { const i = argv.indexOf('--' + n); return i >= 0 ? argv.splice(i, 2)[1] : null; };
const keyFile = opt('key') || process.env.SCOREDESK_KEY_FILE;
const vaultDir = opt('vault') || path.join(__dirname, 'vault');
const plainDir = opt('plain');
const indexPath = argv[0];
if (!indexPath){
  console.error('Usage: node run_suite.js path/to/index.html --key my.key [--vault ./vault]');
  process.exit(2);
}

// --- Extract the parsing engine out of index.html ------------------------
// We deliberately don't hand-copy the parser into this suite: that would let
// the suite quietly drift from what's actually shipped. Instead we pull the
// real <script> block straight out of the file being tested, so this suite
// always exercises the exact code a user's browser would run.
const html = fs.readFileSync(indexPath, 'utf8');
const scriptMatches = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
if (scriptMatches.length === 0){
  console.error('No inline <script> blocks found in ' + indexPath);
  process.exit(2);
}
// The parsing engine lives in the largest inline script block.
const mainScript = scriptMatches.map(m => m[1]).sort((a, b) => b.length - a.length)[0];

// Grab just the parsing-relevant slice: from clean() (the first pure text-
// utility function) through the end of parseFormatE (the last-resort
// generic parser). Deliberately NOT starting at the parsedAccounts
// declaration — the span between that and clean() holds DOM element consts
// and the OCR canvas helpers, which need a real browser and aren't parsing
// logic. The four global state vars are simple enough to declare directly.
const startMarker = 'function clean(s){';
const endMarker = /\nfunction parseFormatE\(text\)\{[\s\S]*?\n\}\n/;
const startIdx = mainScript.indexOf(startMarker);
const endMatch = mainScript.slice(startIdx).match(endMarker);
if (startIdx === -1 || !endMatch){
  console.error('Could not locate the parsing engine boundaries in this index.html.');
  console.error('(This usually means function names were refactored — update the markers in run_suite.js.)');
  process.exit(2);
}
const globalState = "let parsedAccounts = [];\nlet parsedEnquiries = [];\nlet consumerName = '';\nlet reportMeta = {};\n";
const engineSrc = globalState + mainScript.slice(startIdx, startIdx + endMatch.index + endMatch[0].length);

// htmlToText lives earlier in the file (it's used by the HTML upload path,
// which runs before any of the parseReport machinery). Needed for .html
// fixtures — extracted separately since it sits outside the clean()..
// parseFormatE span above.
const htmlToTextMatch = mainScript.match(/const HTML_BLOCK_TAGS[\s\S]*?function htmlToText\(root\)\{[\s\S]*?\n\}\n/);
const htmlToTextSrc = htmlToTextMatch ? htmlToTextMatch[0] : '';

let JSDOM = null;
try { JSDOM = require('jsdom').JSDOM; } catch (e) { /* optional — only needed for .html fixtures */ }

// A couple of DOM-free stand-ins the parsing code doesn't actually need for
// text parsing but may reference incidentally (defensive — keeps the suite
// resilient to minor refactors that don't change parsing logic itself).
const sandbox = {
  console,
  module: { exports: {} },
};
vm.createContext(sandbox);
try {
  vm.runInContext(
    htmlToTextSrc + '\n' + engineSrc + '\nmodule.exports = { parseReport, htmlToText, get parsedAccounts(){return parsedAccounts;}, get parsedEnquiries(){return parsedEnquiries;}, get consumerName(){return consumerName;}, get reportMeta(){return reportMeta;} };',
    sandbox,
    { filename: 'extracted-engine.js' }
  );
} catch (e){
  console.error('Extracted engine failed to load:', e.message);
  process.exit(2);
}
const engine = sandbox.module.exports;

// --- Run every fixture ----------------------------------------------------
let data;   // Map: logical file name -> Buffer
if (plainDir){
  data = new Map(fs.readdirSync(plainDir).map(f => [f, fs.readFileSync(path.join(plainDir, f))]));
} else {
  try { data = require('./vault.js').loadVault(vaultDir, keyFile); }
  catch (e){ console.error('Cannot open the encrypted suite data: ' + e.message); process.exit(2); }
}
if (!data.has('expected.json')){ console.error('expected.json missing from the data set.'); process.exit(2); }
const expected = JSON.parse(data.get('expected.json').toString('utf8'));

let pass = 0, fail = 0;
for (const [fname, exp] of Object.entries(expected)){
  if (!data.has(fname)){
    console.log(`SKIP  ${fname}  (fixture file missing)`);
    continue;
  }
  let text;
  if (exp.isHtml){
    if (!JSDOM){
      console.log(`SKIP  ${fname}  (needs 'npm install jsdom' to test the HTML upload path)`);
      continue;
    }
    const dom = new JSDOM(data.get(fname).toString('utf8'));
    text = engine.htmlToText(dom.window.document.body || dom.window.document.documentElement);
  } else {
    text = data.get(fname).toString('utf8');
  }
  engine.parseReport(text);

  const problems = [];
  if (exp.consumerName && engine.consumerName !== exp.consumerName){
    problems.push(`consumerName: got "${engine.consumerName}", expected "${exp.consumerName}"`);
  }
  if (exp.score && engine.reportMeta.score !== exp.score){
    problems.push(`score: got "${engine.reportMeta.score}", expected "${exp.score}"`);
  }
  if (typeof exp.minAccounts === 'number' && engine.parsedAccounts.length < exp.minAccounts){
    problems.push(`accounts: got ${engine.parsedAccounts.length}, expected at least ${exp.minAccounts}`);
  }
  if (typeof exp.enquiries === 'number' && engine.parsedEnquiries.length !== exp.enquiries){
    problems.push(`enquiries: got ${engine.parsedEnquiries.length}, expected ${exp.enquiries}`);
  }
  const artifactCount = (engine.reportMeta.parsingArtifacts || []).length;
  if (typeof exp.maxArtifacts === 'number' && artifactCount > exp.maxArtifacts){
    problems.push(`parsing artifacts: got ${artifactCount}, expected at most ${exp.maxArtifacts} — ` +
      engine.reportMeta.parsingArtifacts.map(a => `[row ${a.accountIdx} ${a.field}: "${a.value.slice(0,40)}"]`).join(', '));
  }

  const dg = engine.reportMeta.diagnostics || {};
  if (exp.confidence && dg.confidence !== exp.confidence){
    problems.push(`confidence: got "${dg.confidence}", expected "${exp.confidence}"`);
  }
  if (process.env.SHOW_DIAG){
    console.log(`  [diag] ${fname}: format=${dg.formatId} confidence=${dg.confidence} fill=${JSON.stringify(dg.fillRates)}`);
  }
  if (problems.length === 0){
    pass++;
    console.log(`PASS  ${fname}  (${engine.parsedAccounts.length} accounts, ${engine.parsedEnquiries.length} enquiries, ${dg.formatId}/${dg.confidence})`);
  } else {
    fail++;
    console.log(`FAIL  ${fname}`);
    problems.forEach(p => console.log(`        - ${p}`));
  }
}

console.log('');
console.log(`${pass} passed, ${fail} failed (of ${pass + fail} fixtures)`);
process.exit(fail > 0 ? 1 : 0);
