# ScoreDesk Vault — guide for a developer or AI assistant

This guide contains **no secrets** and is safe to share. The **key file**
(`scoredesk-vault.key`) is the secret; this guide explains how to use it.

## What this is
ScoreDesk is a browser tool that reads CIBIL/credit-bureau reports. Its
regression suite needs sample reports, and those contain real people's
personal data. So the samples, the expected results, and even the file names
are stored **encrypted** in `vault/`. Without the key file, `vault/` is
meaningless binary.

- Cipher: **AES-256-GCM** (standard, authenticated). Not a custom cipher —
  the secrecy comes only from the 256-bit key.
- Container: `.sdv` ("ScoreDesk Vault"). Layout: `SDV1 | keyId(4) | nonce(12) | ciphertext | tag(16)`.
  Each blob's logical name is bound into the encryption (AAD), so renaming or
  swapping files is detected. Physical file names are HMAC-derived and opaque.
- `vault/manifest.sdv` is the encrypted index of what the vault holds.
- Only Node.js built-ins are used (no installs). Works in Termux on Android.

## Running the tests
```
node run_suite.js path/to/index.html --key scoredesk-vault.key
node unit_tests.js path/to/index.html          # no key needed
```
Data is decrypted in memory only and never written to disk. A wrong key is
refused with a clear message; any tampering fails authentication.
(`npm install` once, if you want the saved-HTML fixture tested — it needs jsdom.)

## Working with the vault
```
node vault.js list   vault --key K            # names + sizes
node vault.js cat    vault <name> --key K      # print ONE file (for review)
node vault.js add    <file> vault --key K      # add/replace a fixture, then delete the plaintext
node vault.js verify vault --key K
node vault.js open   vault <out_dir> --key K   # writes PLAINTEXT — delete after use
```
To add a new sample report: save its extracted text, `add` it, add an entry
for it inside `expected.json` (`cat` it, edit, `add` it back), run the suite.

## Rules for whoever holds the key
1. Treat the extracted text as confidential personal financial data.
2. Never commit the key or the decrypted data to GitHub (the site repo is public).
3. Don't paste decrypted reports into tools/chats you don't control.
4. Prefer `cat <one file>` over `open` — give out the least you need.

## For the owner: sharing safely
- Giving someone the key file = giving them everything in the vault. Share it
  only for the task, then **rotate**:
  `node vault.js keygen new.key` then
  `node vault.js rekey vault vault_new --key old.key --new new.key`,
  and destroy the old key + old vault. Anyone with the OLD key can still
  read any copy of the OLD vault they saved.
- If you paste the key into an AI chat, that chat provider and anyone with
  access to the conversation can see it. Rotate afterwards.
- **There is no recovery.** Lose every copy of the key and the data is gone.
  Keep one backup, stored away from the vault.
